
#!/usr/bin/env python3
"""
AXEZENT ACI — CERTIFIED FINITE VERIFIER
Problem: van der Waerden number W(2,3)

Claim:
- There exists a 2-coloring of {1..8} with no monochromatic 3-term AP.
- No 2-coloring of {1..9} avoids a monochromatic 3-term AP.
Conclusion: W(2,3) = 9.

This verifier exhaustively checks all colorings.
"""

from itertools import product

def has_mono_3ap(coloring):
    n = len(coloring)
    for a in range(1, n+1):
        for d in range(1, (n - a)//2 + 1):
            i = a - 1
            j = a + d - 1
            k = a + 2*d - 1
            if coloring[i] == coloring[j] == coloring[k]:
                return True
    return False

def count_avoiders(n):
    count = 0
    example = None
    for coloring in product([0,1], repeat=n):
        if not has_mono_3ap(coloring):
            count += 1
            if example is None:
                example = coloring
    return count, example

if __name__ == "__main__":
    c8, ex8 = count_avoiders(8)
    c9, ex9 = count_avoiders(9)

    print("n=8 avoiders:", c8)
    print("example avoider n=8:", ex8)
    print("n=9 avoiders:", c9)
    print("example avoider n=9:", ex9)
